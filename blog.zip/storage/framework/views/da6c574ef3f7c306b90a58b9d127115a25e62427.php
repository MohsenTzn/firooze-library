<?php if(Auth::check()): ?>
<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">تاییدیه سفارش</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <form method="POST" action="/lending_update/<?php echo e($lending->id); ?>" style="direction: rtl">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('PATCH')); ?>

                            <div class="form-group row">
                                <label for="book_id" class="col-md-4 col-form-label text-md-right"> نام کتاب</label>

                                <div class="col-md-6">
                                    <select class="form-control" id="book_id" name="book_id" required>
                                        <option value="<?php echo e(\App\book::find($lending->book_id)->id); ?>" ><?php echo e(\App\book::find($lending->book_id)->name); ?></option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row" style="display: none">
                                <label for="user_id" class="col-md-4 col-form-label text-md-right"></label>
                                <div class="col-md-6">
                                    <input id="user_id" value="<?php echo e(Auth::user()->id); ?>" type="text" class="form-control" name="user_id" required>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="lending_date" class="col-md-4 col-form-label text-md-right"> تاریخ قرض گرفتن کتاب</label>
                                <div class="col-md-6">
                                    <input id="lending_date" value="<?php echo e($lending->lending_date); ?>" name="lending_date"  type="date" class="form-control">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="return_date" class="col-md-4 col-form-label text-md-right">تاریخ بازگشت کتاب</label>
                                <div class="col-md-6">
                                    <input id="return_date" type="date" value="<?php echo e($lending->return_date); ?>" class="form-control" name="return_date">
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit"  class="btn btn-primary">
                                        ثبت سفارش
                                    </button>
                                </div>
                            </div>

                            <br>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!-- //The lending date must be a date after today. The return date must be a date before !-->
                                            <?php if((strpos($error , "before") !== false)): ?>
                                                <li>مهلت ارسال کتاب نهایتا تا 14 روز پس از تحویل کتاب است</li>
                                            <?php endif; ?>
                                            <?php if(@$error == "The lending date must be a date after yesterday."): ?>
                                                <li>تاریخ قرض گرفن کتاب قبل از امروز نمیتواند باشد</li>
                                            <?php endif; ?>
                                            <?php if(@$error == "The return date field is required."): ?>
                                                <li>وارد کردن تاریخ بازگشت الزامیست</li>
                                            <?php endif; ?>
                                            <?php if(@$error == "The lending date field is required."): ?>
                                                <li>وارد کردن تاریخ ارسال الزامیست</li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">تاییدیه سفارش</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <form method="POST" action="/lending_update/<?php echo e($lending->id); ?>" style="direction: rtl">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('PATCH')); ?>

                            <div class="form-group row">
                                <label for="book_id" class="col-md-4 col-form-label text-md-right"> نام کتاب</label>

                                <div class="col-md-6">
                                    <select class="form-control" id="book_id" name="book_id" required>
                                        <option value="<?php echo e(\App\book::find($lending->book_id)->id); ?>" ><?php echo e(\App\book::find($lending->book_id)->name); ?></option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row" style="display: none">
                                <label for="user_id" class="col-md-4 col-form-label text-md-right"></label>
                                <div class="col-md-6">
                                    <input id="user_id" value="<?php echo e(Auth::user()->id); ?>" type="text" class="form-control" name="user_id" required>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="lending_date" class="col-md-4 col-form-label text-md-right"> تاریخ قرض گرفتن کتاب</label>
                                <div class="col-md-6">
                                    <input id="lending_date" value="<?php echo e($lending->lending_date); ?>" name="lending_date"  type="date" class="form-control">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="return_date" class="col-md-4 col-form-label text-md-right">تاریخ بازگشت کتاب</label>
                                <div class="col-md-6">
                                    <input id="return_date" type="date" value="<?php echo e($lending->return_date); ?>" class="form-control" name="return_date">
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit"  class="btn btn-primary">
                                        ثبت سفارش
                                    </button>
                                </div>
                            </div>

                            <br>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!-- //The lending date must be a date after today. The return date must be a date before !-->
                                            <?php if((strpos($error , "before") !== false)): ?>
                                                <li>مهلت ارسال کتاب نهایتا تا 14 روز پس از تحویل کتاب است</li>
                                            <?php endif; ?>
                                            <?php if(@$error == "The lending date must be a date after yesterday."): ?>
                                                <li>تاریخ قرض گرفن کتاب قبل از امروز نمیتواند باشد</li>
                                            <?php endif; ?>
                                            <?php if(@$error == "The return date field is required."): ?>
                                                <li>وارد کردن تاریخ بازگشت الزامیست</li>
                                            <?php endif; ?>
                                            <?php if(@$error == "The lending date field is required."): ?>
                                                <li>وارد کردن تاریخ ارسال الزامیست</li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <?php if(Auth::check()): ?>
                        <div class="card-header">اضافه کردن کتاب</div>
                    <?php else: ?>
                        <div class="card-header">خطا</div>
                    <?php endif; ?>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <a href="/login">ابتدا باید وارد سایت شوید...</a>
                        <script type="text/javascript">
                            var count = 5;
                            var redirect = "/login";

                            function countDown(){
                                var timer = document.getElementById("timer");
                                if(count > 0){
                                    count--;
                                    timer.innerHTML ="<p>" + count + "</p>";
                                    //delay for 1000ms
                                    setTimeout("countDown()", 1000);
                                }else{
                                    window.location.href = redirect;
                                }
                            }

                        </script>
                        <br>
                        <span id="timer">
                            <script type="text/javascript">countDown();</script>
                            </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\Projects\Sabzevar Sampad Library\blog\resources\views/update_lending_form.blade.php ENDPATH**/ ?>